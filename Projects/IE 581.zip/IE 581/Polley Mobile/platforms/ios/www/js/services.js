angular.module('starter.services', [])



.factory('Favorites', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var favorites = [
    { id: 0, name: 'Welch Ave' },
    { id: 1, name: 'West Street Deli' },
    { id: 2, name: 'The Cafe'},
    { id: 3, name: "Wendy's" }
  ];

  return {
    all: function() {
      return favorites;
    },
    get: function(favoriteId) {
      // Simple index lookup
      return favorites[favoriteId];
    }
  }
})







.factory('Coupons', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var coupons = [
    { id: 0, name: 'Welch Ave', value: '10% off next purchase', expiration: "3/3/2015" },
    { id: 1, name: 'West Street Deli', value: 'free cookie', expiration: "1/3/2015" },
    { id: 2, name: 'The Cafe', value: '10% off next purchase', expiration: "2/14/2015"},
    { id: 3, name: 'Charlie Yokes', value: '10% off next purchase', expiration: "1/1/2015" }
  ];

  return {
    all: function() {
      return coupons;
    },
    get: function(couponId) {
      // Simple index lookup
      return coupons[couponId];
    }
  }
})


/**
 * A simple example service that returns some data.
 */
.factory('Friends', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var friends = [
    { id: 0, name: 'Welch Ave', question1: "Do you like this Place?", question2: "Do you like Minnow Farmers?"  },
    { id: 1, name: 'West Street Deli', question1: "Do you like this Place?", question2: "Do you like sandwiches?"  },
    { id: 2, name: 'The Cafe', question1: "Do you like this Place?", question2: "Do you like free food?"  },
    { id: 3, name: 'Charlie Yokes', question1: "Do you like this Place?", question2: "Do you like free beer?" }
  ];

  return {
    all: function() {
      return friends;
    },
    get: function(friendId) {
      // Simple index lookup
      return friends[friendId];
    }
  }
});
