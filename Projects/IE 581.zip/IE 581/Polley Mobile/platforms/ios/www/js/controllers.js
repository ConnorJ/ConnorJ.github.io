angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope, Friends) {
  $scope.friends = Friends.all();
})

.controller('CouponCtrl', function($scope, Coupons) {
  $scope.coupons = Coupons.all();
})

.controller('coupon-detailCtrl', function($scope, $stateParams, Coupons) {
  $scope.coupon = Coupons.get($stateParams.couponId);
})

.controller('FavoriteCtrl', function($scope, Favorites) {
  $scope.favorites = Favorites.all();
})

.controller('favorite-detailCtrl', function($scope, $stateParams, Favorites) {
  $scope.favorite = Favorites.get($stateParams.favoriteId);
})

.controller('FriendsCtrl', function($scope, Friends) {
  $scope.friends = Friends.all();
})



.controller('FriendDetailCtrl', function($scope, $stateParams, Friends) {
  $scope.friend = Friends.get($stateParams.friendId);
})



.controller('AccountCtrl', function($scope) {
});
