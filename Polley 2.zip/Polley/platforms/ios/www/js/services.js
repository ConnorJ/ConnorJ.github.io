angular.module('starter.services', [])

 .factory('Post', function($resource) {
  return $resource('/api/post/:id');
})




.factory('Favorites', function($http) {
  // Might use a resource here that returns a JSON array

  var favorites = [
    { id: 0, name: 'Welch Ave', rating: "4.6", description: 'Solid prices, great beer selection, pool tables.', website: "google.com" },
     { id: 1, name: 'West Street Deli', rating: "4.9", description: 'Made from scratch soups, sides, desserts. House cooked and smoked meats, and sausages. Locally baked breads. Supports locally grown produce.', website: "google.com" },
  { id: 2, name: 'The Cafe', rating: "4.7", description: '...people who believe that good food, good drink and good company are some of the most rewarding ingredients life has to offer.', website: "http://www.thecafeames.com/"},
        ];

  return {
    all: function() {
        return favorites;
    },
    get: function(favoriteId) {
      // Simple index lookup
      return favorites[favoriteId];
    }
  }
})


.factory('Answers', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var answers = [
    { id: 0, name: 'Welch Ave', rating: "4.6", description: 'Solid prices, great beer selection, pool tables.', website: "google.com" },
    { id: 1, name: 'West Street Deli', rating: "4.9", description: 'Made from scratch soups, sides, desserts. House cooked and smoked meats, and sausages. Locally baked breads. Supports locally grown produce.', website: "google.com" },
    { id: 2, name: 'The Cafe', rating: "4.7", description: '...people who believe that good food, good drink and good company are some of the most rewarding ingredients life has to offer.', website: "http://www.thecafeames.com/"},
   ];

  return {
    all: function() {
      return answers;
    },
    get: function(answerId) {
      // Simple index lookup
      return answers[answerId];
    }
  }
})








.factory('Coupons', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var coupons = [
    { id: 0, name: 'Welch Ave', value: '10% off next purchase', expiration: "3/3/2015"},
    { id: 1, name: 'West Street Deli', value: 'free cookie', expiration: "1/3/2015"},
    { id: 2, name: 'The Cafe', value: '10% off next purchase', expiration: "2/14/2015"},
    { id: 3, name: 'Charlie Yokes', value: '10% off next purchase', expiration: "1/1/2015"}
  ];

  return {
    all: function() {
      return coupons;
    },
    get: function(couponId) {
      // Simple index lookup
      return coupons[couponId];
    }
  }
})


/**
 * A simple example service that returns some data.
 */
.factory('Friends', function() {
  // Might use a resource here that returns a JSON array

  // Some fake testing data
  var friends = [
    { id: 0, name: 'Welch Ave', question1: "Do you like this Place?", answers1: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], question2: "Do you like Minnow Farmers?", value: '10% off next purchase', answers2: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ]  },
    { id: 1, name: 'West Street Deli', question1: "Do you like this Place?", answers1: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], question2: "Do you like sandwiches?", answers2: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], value: 'free cookie'  },
    { id: 2, name: 'The Cafe', question1: "Do you like this Place?", answers1: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], question2: "Do you like free food?" , answers2: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], value: '15% off sandwiches' },
    { id: 3, name: 'Charlie Yokes', question1: "Do you like this Place?", answers1: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], question2: "Do you like free beer?", answers2: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], value: '10% off next purchase' },
    { id: 4, name: 'Fighting Burrito', question1: "Do you like this Place?", answers1: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], question2: "Do you go to chipotle?", answers2: [
                                {
                                    id: 1,
                                    name: "Yes"
                                },
                                {
                                    id: 2,
                                    name: "No"
                                }
                            ], value: '5% off next purchase' }
  ];

  return {
    all: function() {
      return friends;
    },
    get: function(friendId) {
      // Simple index lookup
      return friends[friendId];
    }
  }
});
