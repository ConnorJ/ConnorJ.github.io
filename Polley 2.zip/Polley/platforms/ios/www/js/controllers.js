angular.module('starter.controllers', [])


.controller('SignInCtrl', function($scope, $state) { 
  $scope.signIn = function(user) {
    console.log('Sign-In', user);
    $state.go('tab.dash');
  };
  
})

.controller('HomeTabCtrl', function($scope) {
  console.log('HomeTabCtrl');
})



.controller('DashCtrl', function($scope, Friends) {
  $scope.friends = Friends.all();
})

.controller('CouponCtrl', function($scope, $http, Coupons) {

  $http.get("http://www.cs.iastate.edu/~tgreiner/coupon.php", { params: { "id": "state0", "name": "state1", "value": "state2", "expiration": "state3" } })
    .success(function(data) {
        $scope.coupons = data;
       
    })
    .error(function(data) {
        alert("Unable to load Coupons");
    });

 // $scope.coupons = Coupons.all();
})

.controller('coupon-detailCtrl', function($scope, $stateParams, Coupons) {
  $scope.coupon = Coupons.get($stateParams.couponId);
})

.controller('FavoriteCtrl', function($scope, $http, Favorites) {

  $http.get("http://www.cs.iastate.edu/~tgreiner/favorite.php", { params: { "storename": "state1", "rating": "state2", "id": "state3"  } })
    .success(function(data) {
        $scope.favorites = data;
       
    })
    .error(function(data) {
        alert("Unable to load Favorites");
    });


//$scope.favorites = Favorites.all();
})

.controller('favorite-detailCtrl', function($scope, $stateParams, $http, Favorites) {
 //$http.get("http://www.cs.iastate.edu/~tgreiner/favorite.php", { params: { "storename": "state1", "rating": "state2", "id": "state3"  } })
   // .success(function(data) {
     //   var rep = data;
       // $scope.favorites = rep[$stateParams.favoriteId];
 //   })
  //  .error(function(data) {
  //      alert("Unable to load Favorites");
  //  });


    $scope.favorite = Favorites.get($stateParams.favoriteId);


})

.controller('Favorites-SearchCtrl', function ($scope, $http) {

   $http.get("http://www.cs.iastate.edu/~tgreiner/favorite.php", { params: { "storename": "state1", "rating": "state2", "id": "state3"  } })
    .success(function(data) {
        $scope.companies = data;
    })
    .error(function(data) {
        alert("Unable to load Companies");
    });
})



.controller('FriendsCtrl', function($scope, Friends) {
  $scope.friends = Friends.all();
})

.controller('FriendDetailCtrl', function($scope, $stateParams, Friends, Post) {

  $scope.friend = Friends.get($stateParams.friendId);

    // Get all posts
  $scope.posts = Post.query();

  // Our form data for creating a new post with ng-model
  $scope.postData = {};
  $scope.newPost = function() {
    var post = new Post($scope.postData);
  
    post.$save();
  }

  //$scope.friend = Friends.get($stateParams.friendId);
})


.controller('AccountCtrl', function($scope, $http) {



  //$scope.getData = function() {
$http.get("http://www.cs.iastate.edu/~tgreiner/test.php", { params: { "name": "state" } })
    .success(function(data) {
        $scope.conditions = data.conditions;
    })
    .error(function(data) {
        alert("ERROR");
    });
  //}

 // $http.get('http://www.cs.iastate.edu/~tgreiner/test.json', {params: { "name": "state" } }).success(function(data) {
  //   $scope.conditions = data.conditions;
//  }).error(function(data) {
//   alert("Error");
//  }) 

});
